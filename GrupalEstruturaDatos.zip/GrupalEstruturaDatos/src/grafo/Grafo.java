package grafo;

import java.util.*;

public class Grafo {
    // Estructuras para almacenar los nodos y las aristas
    private Map<String, NodoGrafo> nodos;
    private Map<String, Map<String, Double>> adyacencias;

    public Grafo() {
        // Constructor para inicializar las estructuras
        nodos = new HashMap<>();
        adyacencias = new HashMap<>();
    }

    // Métodos como insertarNodo, borrarNodo, insertarArista, etc.

    //MÉTODO INSERTAR NODO
    public boolean insertarNodo(NodoGrafo nodo) {
        if (nodos.containsKey(nodo.getClave())) {
            return false; // El nodo ya existe
        }
        nodos.put(nodo.getClave(), nodo);
        adyacencias.put(nodo.getClave(), new HashMap<>());
        return true;
    }

    //MÉTODO BORRAR NODO
    public boolean borrarNodo(String clave) {
        if (!nodos.containsKey(clave)) {
            return false; // El nodo no existe
        }
        nodos.remove(clave);
        adyacencias.remove(clave);

        // También hay que eliminar todas las aristas que conectan con este nodo
        for (String key : adyacencias.keySet()) {
            adyacencias.get(key).remove(clave);
        }
        return true;
    }
   // MÉTODO EXISTE NODO
   public boolean existeNodo(String clave) {
       return nodos.containsKey(clave);
   }

   // MÉTODO NÚMERO DE NODOS
   public int numeroNodos() {
       return nodos.size();
   }
// Ahora implementaremos los Métodos para Gestionar Aristas

    // MÉTODO INSERTAR ARISTA

    public boolean insertarArista(String clave1, String clave2, Double peso) {
        if (!nodos.containsKey(clave1) || !nodos.containsKey(clave2)) {
            return false; // Uno de los nodos no existe
        }

        Map<String, Double> aristasNodo1 = adyacencias.get(clave1);
        if (aristasNodo1.containsKey(clave2)) {
            return false; // La arista ya existe
        }

        // Añadir la arista en ambos sentidos ya que el grafo es no dirigido
        aristasNodo1.put(clave2, peso);
        adyacencias.get(clave2).put(clave1, peso);
        return true;
    }

    //MÉTODO BORRAR ARISTA
    public boolean borrarArista(String clave1, String clave2) {
        if (!nodos.containsKey(clave1) || !nodos.containsKey(clave2)) {
            return false; // Uno de los nodos no existe
        }

        Map<String, Double> aristasNodo1 = adyacencias.get(clave1);
        if (!aristasNodo1.containsKey(clave2)) {
            return false; // La arista no existe
        }

        // Eliminar la arista en ambos sentidos
        aristasNodo1.remove(clave2);
        adyacencias.get(clave2).remove(clave1);
        return true;
    }

    //MÉTODO EXISTE ARISTA
    public boolean existeArista(String clave1, String clave2) {
        return nodos.containsKey(clave1) &&
                nodos.containsKey(clave2) &&
                adyacencias.get(clave1).containsKey(clave2);
    }

    //MÉTODO PARA NÚMERO DE ARISTAS
    public int numeroAristas() {
        int contador = 0;
        for (String clave : adyacencias.keySet()) {
            contador += adyacencias.get(clave).size();
        }
        return contador / 2; // Cada arista se cuenta dos veces, una por cada nodo
    }

    // Método toString para Representación del Grafo
    //El método toString mostrará una representación textual del grafo, utilizando el formato de listas de adyacencias.

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, Map<String, Double>> nodo : adyacencias.entrySet()) {
            builder.append(nodo.getKey()).append(": ");
            for (Map.Entry<String, Double> arista : nodo.getValue().entrySet()) {
                builder.append(arista.getKey()).append("(").append(arista.getValue()).append("), ");
            }
            builder.setLength(builder.length() - 2); // Eliminar la última coma y espacio
            builder.append("\n");
        }
        return builder.toString();
    }
// AHORA VAMOS A IMPLEMENTAR EL ALGORITMO DE DIJKSTRA

    // 1- versión que devuelve el vector de distancias mínimas desde un nodo fuente a todos los otros nodos.
    // 2- versión que devuelve el camino más corto entre dos nodos específicos.

    //MÉTODO 1: Algoritmo de Dijkstra para Vector de Distancias Mínimas
    // Método para calcular el vector de distancias mínimas

    public Map<String, Double> dijkstra(String nodoFuente) {
        Map<String, Double> distancias = new HashMap<>();
        PriorityQueue<Map.Entry<String, Double>> colaPrioridad = new PriorityQueue<>(Map.Entry.comparingByValue());

        // Inicializar distancias
        for (String nodo : nodos.keySet()) {
            if (nodo.equals(nodoFuente)) {
                distancias.put(nodo, 0.0);
            } else {
                distancias.put(nodo, Double.MAX_VALUE);
            }
        }

        colaPrioridad.add(new AbstractMap.SimpleEntry<>(nodoFuente, 0.0));

        while (!colaPrioridad.isEmpty()) {
            Map.Entry<String, Double> nodoActual = colaPrioridad.poll();

            // Recorrer todos los nodos adyacentes
            for (Map.Entry<String, Double> adyacente : adyacencias.get(nodoActual.getKey()).entrySet()) {
                String nodoVecino = adyacente.getKey();
                Double pesoArista = adyacente.getValue();

                // Calcular nueva distancia
                double nuevaDistancia = nodoActual.getValue() + pesoArista;

                // Si la nueva distancia es más corta, actualizar
                if (nuevaDistancia < distancias.get(nodoVecino)) {
                    distancias.put(nodoVecino, nuevaDistancia);
                    colaPrioridad.add(new AbstractMap.SimpleEntry<>(nodoVecino, nuevaDistancia));
                }
            }
        }

        return distancias;
    }
    // MÉTODO 2: Algoritmo de Dijkstra para el Camino Más Corto
    // Método para calcular el camino más corto entre dos nodos
    public List<String> dijkstra(String nodoInicio, String nodoFin) {
        if (!nodos.containsKey(nodoInicio) || !nodos.containsKey(nodoFin)) {
            return null; // Uno de los nodos no existe
        }

        Map<String, Double> distancias = new HashMap<>();
        Map<String, String> predecesores = new HashMap<>();
        PriorityQueue<Map.Entry<String, Double>> colaPrioridad = new PriorityQueue<>(Map.Entry.comparingByValue());

        for (String nodo : nodos.keySet()) {
            distancias.put(nodo, Double.MAX_VALUE);
            predecesores.put(nodo, null);
        }

        distancias.put(nodoInicio, 0.0);
        colaPrioridad.add(new AbstractMap.SimpleEntry<>(nodoInicio, 0.0));

        while (!colaPrioridad.isEmpty()) {
            Map.Entry<String, Double> nodoActual = colaPrioridad.poll();
            String nodoActualKey = nodoActual.getKey();

            if (nodoActualKey.equals(nodoFin)) {
                break; // Hemos llegado al nodo final
            }

            for (Map.Entry<String, Double> adyacente : adyacencias.get(nodoActualKey).entrySet()) {
                String nodoVecino = adyacente.getKey();
                Double pesoArista = adyacente.getValue();

                double nuevaDistancia = distancias.get(nodoActualKey) + pesoArista;
                if (nuevaDistancia < distancias.get(nodoVecino)) {
                    distancias.put(nodoVecino, nuevaDistancia);
                    predecesores.put(nodoVecino, nodoActualKey);
                    colaPrioridad.add(new AbstractMap.SimpleEntry<>(nodoVecino, nuevaDistancia));
                }
            }
        }

        // Reconstruir el camino más corto
        List<String> camino = new ArrayList<>();
        for (String nodo = nodoFin; nodo != null; nodo = predecesores.get(nodo)) {
            camino.add(nodo);
        }
        Collections.reverse(camino);
        return camino.size() > 1 ? camino : null; // Devuelve null si no hay camino
    }

}
