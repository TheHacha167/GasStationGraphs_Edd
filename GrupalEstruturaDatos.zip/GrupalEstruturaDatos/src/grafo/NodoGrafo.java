package grafo;

public interface NodoGrafo {
    public String getClave();
}
