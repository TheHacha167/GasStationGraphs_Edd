package grafo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Grafo grafo = new Grafo();
        List<Gasolinera> gasolineras = leerGasolineras("data/gasolineras.txt");
        for (Gasolinera gasolinera : gasolineras) {
            grafo.insertarNodo(gasolinera);
        }
        leerConexiones(grafo, "data/conexiones.txt");

        // Imprimir el grafo
        System.out.println("Grafo de Gasolineras:");
        System.out.println(grafo);

        // Interacción con el usuario para el algoritmo de Dijkstra
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese la clave de la gasolinera de origen:");
        String origen = scanner.nextLine();
        System.out.println("Ingrese la clave de la gasolinera de destino:");
        String destino = scanner.nextLine();

        List<String> camino = grafo.dijkstra(origen, destino);
        if (camino != null) {
            System.out.println("Camino más corto de " + origen + " a " + destino + ": " + camino);
        } else {
            System.out.println("No hay un camino entre " + origen + " y " + destino);
        }

        scanner.close();
    }

    private static List<Gasolinera> leerGasolineras(String rutaArchivo) {
        List<Gasolinera> gasolineras = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 5) {
                    Gasolinera gasolinera = new Gasolinera(datos[0].trim(), datos[1].trim(), datos[2].trim(), datos[3].trim(), datos[4].trim());
                    gasolineras.add(gasolinera);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return gasolineras;
    }

    private static void leerConexiones(Grafo grafo, String rutaArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 3) {
                    String clave1 = datos[0].trim();
                    String clave2 = datos[1].trim();
                    double distancia = Double.parseDouble(datos[2].trim());
                    grafo.insertarArista(clave1, clave2, distancia);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

